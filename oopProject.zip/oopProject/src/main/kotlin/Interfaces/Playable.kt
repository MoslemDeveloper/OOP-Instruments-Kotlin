package net.moslemdeveloper.Interfaces

interface Playable {
    fun play()
    fun stop()
}