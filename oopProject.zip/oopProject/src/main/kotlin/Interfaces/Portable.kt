package net.moslemdeveloper.Interfaces

interface Portable {
    fun carry()
}