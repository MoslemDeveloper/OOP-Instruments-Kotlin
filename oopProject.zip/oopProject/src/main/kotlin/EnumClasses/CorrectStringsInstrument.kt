package net.moslemdeveloper.EnumClass

enum class CorrectStringsInstrument {
    HeadPhone,
    Wood,
    Iron,
    Copper,
    Aluminum,
    Gold,
    Plastic,


}