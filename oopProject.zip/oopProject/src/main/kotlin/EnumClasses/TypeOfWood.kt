package net.moslemdeveloper.EnumClass

enum class TypeOfWood {
    Maple,
    Mahogany,
    Alder,
}