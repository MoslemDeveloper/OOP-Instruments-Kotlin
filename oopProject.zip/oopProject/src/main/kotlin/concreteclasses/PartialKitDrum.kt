package net.moslemdeveloper.concreteclasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.Interfaces.Playable
import net.moslemdeveloper.abstractClasses.KitDrum

class PartialKitDrum private constructor(
    _name: String,
    _numberOfDrums: Int,
    _hasPedals: Boolean,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    _isComplete: Boolean,
    _numberOfComponents: Int,
    private val _isPracticeSet: Boolean
) : KitDrum(_name, _numberOfDrums, _hasPedals, _hasSound, _bodyMaterial, _isComplete, _numberOfComponents), Playable {
    // secondary constructor
    constructor(
        name : String,
        numberOfDrums: Int,
        hasPedals: Boolean,
        hasSound: Boolean,
        bodyMaterial: CorrectStringsInstrument,
        numberOfComponents: Int,
        isPracticeSet: Boolean
    ) : this(
        _name = name,
        _numberOfDrums = numberOfDrums,
        _hasPedals = hasPedals,
        _hasSound = hasSound,
        _bodyMaterial = bodyMaterial,
        _isComplete = false,
        _numberOfComponents = numberOfComponents,
        _isPracticeSet = isPracticeSet

    )

    override fun produceSound() {
        println("Producing Partial KitDrum sound with limited components...")
    }

    override fun adjustComponents() {
        println("Adjusting available components of the Partial KitDrum...")
    }

    override fun displayInfo() {
        println(
            "Displaying PartialKitDrum information: " +
                    "numberOfComponents=[$numberOfComponents], isPracticeSet=[$_isPracticeSet], isComplete=$isComplete"
        )
    }

    override fun play() {
        println("Playing the instrument...")
    }

    override fun stop() {
        println("Stopping the instrument...")
    }

}