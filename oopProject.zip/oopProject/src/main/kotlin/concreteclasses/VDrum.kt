package net.moslemdeveloper.concreteclasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.Interfaces.Playable
import net.moslemdeveloper.abstractClasses.Drum

class VDrum(
    _name: String,
    _numberOfDrums: Int,
    _hasPedals: Boolean,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    private val numberOfPads: Int,
    private val hasElectronicModule: Boolean
) :
    Drum(_name, _numberOfDrums, _hasPedals, _hasSound, _bodyMaterial), Playable {
    override fun produceSound() {
        println("Producing VDrum sound...")
    }

    // OverLoad function produceSound . . .
    fun produceSound(output: CorrectStringsInstrument) {
        if (output == CorrectStringsInstrument.HeadPhone) {
            println("Producing VDrum sound through headphones .")
        } else {
            println("Producing VDrum sound through speakers...")
        }
    }

    override fun displayInfo() {
        println(
            "Displaying VDrum information: " +
                    "numberOfPads=[$numberOfPads], hasElectronicModule=[$hasElectronicModule]"
        )
    }

    override fun play() {
        println("Playing the instrument...")
    }

    override fun stop() {
        println("Stopping the instrument...")
    }

}