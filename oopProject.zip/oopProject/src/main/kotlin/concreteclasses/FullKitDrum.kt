package net.moslemdeveloper.concreteclasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.Interfaces.Playable
import net.moslemdeveloper.abstractClasses.KitDrum

class FullKitDrum private constructor(
    _name : String,
    _numberOfDrums: Int,
    _hasPedals: Boolean,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    _isComplete: Boolean,
    _numberOfComponents: Int,
    private val _numberOfCymbals: Int,
    private val _numberOfToms: Int,
) : KitDrum(_name,_numberOfDrums, _hasPedals, _hasSound, _bodyMaterial, _isComplete, _numberOfComponents), Playable {

    constructor(
        name : String,
        hasPedals: Boolean,
        hasSound: Boolean,
        bodyMaterial: CorrectStringsInstrument,
        numberOfCymbals: Int,
        numberOfToms: Int,
    ) : this(
        _name = name,
        _numberOfDrums = 8,
        _isComplete = true,
        _numberOfComponents = 5,
        _hasPedals = hasPedals,
        _hasSound = hasSound,
        _bodyMaterial = bodyMaterial,
        _numberOfCymbals = numberOfCymbals,
        _numberOfToms = numberOfToms
    )

    /*constructor(numberOfDrums: Boolean) :
            this(_isComplete = numberOfDrums)*/


    override fun tune() {
        println("The tune is set")
    }

    override fun produceSound() {
        println("Producing full KitDrum sound with all components...")
    }

    override fun adjustComponents() {
        println("Adjusting all components of the full KitDrum for optimal performance...")
    }

    override fun displayInfo() {
        println("Displaying FullKitDrum information: " +
                "numberOfCymbals=[$_numberOfCymbals], numberOfToms=[$_numberOfToms], isComplete=true")
    }

    override fun play() {
        println("Playing the instrument...")
    }

    override fun stop() {
        println("Stopping the instrument...")
    }
}


