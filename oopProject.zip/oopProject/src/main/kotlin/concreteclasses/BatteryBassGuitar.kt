package net.moslemdeveloper.concreteclasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.Interfaces.Playable
import net.moslemdeveloper.Interfaces.Portable
import net.moslemdeveloper.abstractClasses.BassGuitar

class BatteryBassGuitar(
    _name : String,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    _numberOfStrings: Int,
    _hasEqualizer: Boolean,
    private val isRechargeable: Boolean
) : BassGuitar(_name,_hasSound, _bodyMaterial, _numberOfStrings, _hasEqualizer), Playable, Portable {

    override fun produceSound() {
        println("Producing amplified bass guitar sound using battery power...")
    }

    fun checkBatteryStatus() {
        println("Checking battery status for the bass guitar...")
    }

    override fun displayInfo() {
        println("Displaying BatteryBassGuitar information: isRechargeable=[$isRechargeable]")
    }

    override fun play() {
        println("Playing the instrument...")
    }

    override fun stop() {
        println("Stopping the instrument...")
    }

    override fun carry() {
        println("Carrying the instrument to another place...")
    }
}