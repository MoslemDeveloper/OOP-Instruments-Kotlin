package net.moslemdeveloper.concreteclasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.EnumClass.TypeOfWood
import net.moslemdeveloper.Interfaces.Playable
import net.moslemdeveloper.Interfaces.Portable
import net.moslemdeveloper.abstractClasses.BassGuitar

class NonBatteryBassGuitar(
    _name: String,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    _numberOfStrings: Int,
    _hasEqualizer: Boolean,
    private val isAcoustic: Boolean,
    private val woodType: TypeOfWood,
) : BassGuitar(_name, _hasSound, _bodyMaterial, _numberOfStrings, _hasEqualizer), Playable, Portable {
    private var _woodType = woodType
        set(value) {
            if (value in TypeOfWood.values()) {
                field = value
                println("Type Of Wood set to $value")
            } else {
                println("Invalid Type Of Wood! Please choose a valid value!!!.")
            }
        }

    override fun produceSound() {
        println("Producing natural bass guitar sound without any battery power...")
    }

    fun checkBatteryStatus() {
        println("Checking battery status for the bass guitar...")
    }

    override fun displayInfo() {
        println("Displaying NonBatteryBassGuitar information: isAcoustic=[$isAcoustic], woodType=[$woodType]")
    }

    override fun play() {
        println("Playing the instrument...")
    }

    override fun stop() {
        println("Stopping the instrument...")
    }

    override fun carry() {
        println("Carrying the instrument to another place...")
    }

}
