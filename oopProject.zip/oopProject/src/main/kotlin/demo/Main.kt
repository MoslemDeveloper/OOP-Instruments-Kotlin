//In the name of God
package net.moslemdeveloper.demo
import net.moslemdeveloper.EnumClass.CorrectStringsInstrument
import net.moslemdeveloper.EnumClass.TypeOfWood
import net.moslemdeveloper.concreteclasses.BatteryBassGuitar
import net.moslemdeveloper.concreteclasses.FullKitDrum
import net.moslemdeveloper.concreteclasses.NonBatteryBassGuitar
import net.moslemdeveloper.concreteclasses.PartialKitDrum
import net.moslemdeveloper.concreteclasses.VDrum

fun main() {
    //Please uncomment this code when you want to start it for first Time! ♥
    //println("In the name of [Hello]God, [World!]")

    //Test BatteryBassGuitar class With 1 Object
    //obj 1 of BatteryBassGuitar
    println("")
    val ibanezSRSeries = BatteryBassGuitar(
        "ibanezSRSeries", true,
        CorrectStringsInstrument.Iron, 6, false, true
    )

    ibanezSRSeries.selfIntroduction()
    ibanezSRSeries.carry()
    ibanezSRSeries.tune()
    ibanezSRSeries.produceSound()
    ibanezSRSeries.play()
    ibanezSRSeries.displayInfo()
    ibanezSRSeries.checkBatteryStatus()
    ibanezSRSeries.stop()
    println("")
    println("Next")
    println("")
    //Test FullKitDrum class With 1 Object
    //obj 1 of FullKitDrum
    val pearlExportSeries = FullKitDrum(
        "pearlExportSeries", true, true, CorrectStringsInstrument.Aluminum,
        5, 10
    )
    pearlExportSeries.selfIntroduction()
    pearlExportSeries.tune()
    pearlExportSeries.produceSound()
    pearlExportSeries.play()
    pearlExportSeries.displayInfo()
    pearlExportSeries.stop()
    println("")
    println("Next")
    println("")
    //Test NonBatteryBassGuitar class With 1 Object
    //obj 1 of NonBatteryBassGuitar

    val fenderJazzBass = NonBatteryBassGuitar(
        "fenderJazzBass", false,
        CorrectStringsInstrument.Copper, 4, false, true,
        TypeOfWood.Mahogany
    )

    fenderJazzBass.selfIntroduction()
    fenderJazzBass.produceSound()
    fenderJazzBass.play()
    fenderJazzBass.displayInfo()
    fenderJazzBass.checkBatteryStatus()
    fenderJazzBass.stop()
    println("")
    println("Next")
    println("")

    //Test PartialKitDrum class With 1 Object
    //obj 1 of PartialKitDrum
    val yamahaDTX402K = PartialKitDrum(
        "yamahaDTX402K",
        3, false, true,
        CorrectStringsInstrument.Wood, 2, false
    )
    yamahaDTX402K.selfIntroduction()
    yamahaDTX402K.tune()
    yamahaDTX402K.produceSound()
    yamahaDTX402K.play()
    yamahaDTX402K.displayInfo()
    yamahaDTX402K.stop()
    println("")
    println("Next")
    println("")

    //Test VDrum class With 1 Object
    //obj 1 of VDrum
    val rolandTD50kv2 = VDrum(
        "rolandTD50kv2",
        4, true, true,
        CorrectStringsInstrument.Plastic, 2, true
    )
    rolandTD50kv2.selfIntroduction()
    rolandTD50kv2.tune()
    rolandTD50kv2.play()
    rolandTD50kv2.produceSound()
    rolandTD50kv2.displayInfo()
    rolandTD50kv2.produceSound(CorrectStringsInstrument.HeadPhone)
    rolandTD50kv2.stop()
    println("")
    println("End")
    println("")


}