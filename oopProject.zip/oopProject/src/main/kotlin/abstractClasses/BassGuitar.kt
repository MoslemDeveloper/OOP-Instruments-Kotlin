package net.moslemdeveloper.abstractClasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument

abstract class BassGuitar(
    _name: String,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    private val numberOfStrings: Int,
    private val hasEqualizer: Boolean,
) : Instrument(_name, _hasSound, _bodyMaterial) {
    fun tuneStrings() {
        println("Tuning all bass guitar strings to the correct pitch...")
    }

    override fun produceSound() {
        println("Producing the basic bass guitar sound...")
    }


    override fun displayInfo() {
        println("Displaying BassGuitar information: numberOfStrings=[$numberOfStrings], hasEqualizer=[$hasEqualizer]")
    }

}