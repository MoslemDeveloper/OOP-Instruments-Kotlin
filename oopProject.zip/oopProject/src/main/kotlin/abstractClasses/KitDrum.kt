package net.moslemdeveloper.abstractClasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument

abstract class KitDrum(
    _name : String,
    _numberOfDrums: Int,
    _hasPedals: Boolean,
    _hasSound: Boolean,
    _bodyMaterial: CorrectStringsInstrument,
    protected val isComplete: Boolean,
    protected val numberOfComponents: Int
) :
    Drum(_name,_numberOfDrums, _hasPedals, _hasSound, _bodyMaterial) {
    override fun produceSound() {
        println("Producing KitDrum sound...")
    }

    open fun adjustComponents() {
        println("Adjusting KitDrum components for optimal sound...")
    }

    override fun displayInfo() {
        println(
            "Displaying KitDrum information: " +
                    "isComplete=[$isComplete], numberOfComponents=[$numberOfComponents]"
        )

    }
}