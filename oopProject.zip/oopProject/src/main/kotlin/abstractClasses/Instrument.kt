package net.moslemdeveloper.abstractClasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument

abstract class Instrument(
    private val name: String, private val hasSound: Boolean,
    private var bodyMaterial: CorrectStringsInstrument
) {
    // I private it to be sure that it is private,
    //but I know we can't have instance of abstract class,
    //so maybe private here isn't Useful
    //but for other classes that they are send Info to this class,
    //it's very useful to snub reassign fields.
    private var _bodyMaterial = bodyMaterial
        set(value) { // Here, value means what is going to be taken from outside(Main.Kt),
            // so we can't use _bodyMaterial instead of value because _bodyMaterial
            // hasn't been set yet, and we did this manually.
            if (value in CorrectStringsInstrument.values()) { // I use this trick instead of :
                //  if (value == CorrectStrings.Wood)
                field = value
                println("Body material set to $value")
            } else {
                println("Invalid body material! Please choose a valid value!!!.")
            }
        }


    open fun produceSound() {
        println("Producing the basic sound of the instrument...")
    }

    open fun tune() {
        println("Tuning the instrument to the correct pitch...")
    }

    open fun displayInfo() {
        println("Displaying instrument information: hasSound= [$hasSound], bodyMaterial=[$bodyMaterial]")
    }
    fun selfIntroduction(){
        println("Hi")
        println("I'm $name")
    }

}
