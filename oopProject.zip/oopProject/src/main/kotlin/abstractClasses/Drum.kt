package net.moslemdeveloper.abstractClasses

import net.moslemdeveloper.EnumClass.CorrectStringsInstrument

abstract class Drum(
    _name: String, private val numberOfDrums: Int, private val hasPedals: Boolean,
    _hasSound: Boolean, _bodyMaterial: CorrectStringsInstrument
) :
    Instrument(_name, _hasSound, _bodyMaterial) {
    override fun produceSound() {
        println("Producing a generic drum sound...")
    }

    fun adjustPedals() {
        println("Adjusting drum pedals for optimal performance...")
    }

    override fun displayInfo() {
        println("Displaying drum information: numberOfDrums=[$numberOfDrums], hasPedals=[$hasPedals]")
    }
}